class Main {
    public static void main(String... args) {
        for (String s : args) {
            System.out.print(s + " ");
        }
    }   
}
// run something like this ...

// java Main My name is XYZ.