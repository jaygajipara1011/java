class OneDimensionalArray {
    public static void main(String[] args) {
        int array[] = { 1, 2, 3, 4, 5 };
        for (int x : array) {
            System.out.println(x);
        }
    }
}