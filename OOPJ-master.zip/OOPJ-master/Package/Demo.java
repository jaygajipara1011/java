import com.company.project.module.Test;

class Demo extends Test {
    void m() {
        System.out.println("Demo");
    }

    public static void main(String[] args) {
        Demo d = new Demo();
        d.m();
        d.Zzz();
    }
}