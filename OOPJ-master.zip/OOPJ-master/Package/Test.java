package com.company.project.module;

public class Test {
    void m() {
        System.out.println("Test");
    }

    public void Zzz() {
        System.out.println("Zzz");
    }
}
// javac -d . Test.java