class Main {
    public static void main(String args[]) {

        final int x = 10;
        x = 20;             // ERROR : "can't change value of final variable"

    }
}