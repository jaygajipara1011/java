 # 😎 OOPJ Practical Programs...
<!-- 
##### 🗒️ Note :-
- if you are using a Mobile📱, then click on "View code" above to see the code.
--- -->
1. ¯\\\_(ツ)\_/¯ soon...
2. [Odd Even](02/)
3. [String Operation](03/Main.java)
4. [Package](04/)
5. [Multi-threading](05/Main.java)
6. [Deadlock](06/Deadlock.java)
7. [Shapes](07/Main.java)
8. [TCP](08/)
9. [UDP](09/)
10. [Voting](10/Main.java)
11. [Exception Handling](11/Main.java)
12. [BANK](/Extra/Bank/)


---

###### _if you find any errors in code, you can contact me here..._
[![Contact](https://img.shields.io/badge/chat-2d2f2e?style=for-the-badge&logo=whatsapp)](https://api.whatsapp.com/send?phone=919723430561&text=Hi)
[![Contact](https://img.shields.io/badge/Instagram-2d2f2e?style=for-the-badge&logo=instagram)](https://instagram.com/jay__s__p)