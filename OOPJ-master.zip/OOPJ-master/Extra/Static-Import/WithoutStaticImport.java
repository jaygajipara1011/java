class WithoutStaticImport {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(4));
        System.out.println(Math.pow(2, 2));
        System.out.println(Math.abs(-6.3));
    }
}
