class SBlock {
    static{
        System.out.println("Hi");
    }
}
class Main
{
    public static void main(String[] args) {
        SBlock s1 = new SBlock();
        SBlock s2 = new SBlock();
        SBlock s3 = new SBlock();
    }
}